First, run "rawdata_to_img.py"
Then, run "Histogram_equalization"
...
or you can run "bayes.py" directly.
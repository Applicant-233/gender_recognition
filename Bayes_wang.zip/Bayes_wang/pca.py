import os
import cv2
import numpy as np
from PIL import Image

count=0
imageMatrix=[]
#特征脸
for filename in os.listdir(os.getcwd()+"\\"+"output_128\\"):
    count+=1
    img=cv2.imread(os.getcwd()+"\\"+"output_128\\"+filename,cv2.IMREAD_GRAYSCALE)
    #灰度图矩阵
    mats=np.array(img)
    imageMatrix.append(mats.ravel())
imageMatrix=np.array(imageMatrix)



#平均脸
imageMatrix=np.transpose(imageMatrix)
imageMatrix=np.mat(imageMatrix)
mean_img = np.mean(imageMatrix, axis=1)
print(mean_img)
mean_img1 = np.reshape(mean_img,(128,128))
print(mean_img1)
im = Image.fromarray(np.uint8(mean_img1))
im.show()

imageMatrix = imageMatrix - mean_img
# W是特征向量， V是特征向量组
imag_mat = (imageMatrix.T * imageMatrix) / float(count)
W, V = np.linalg.eig(imag_mat)
# V_img是协方差矩阵的特征向量组
V_img = imageMatrix * V
img=np.reshape(V_img.T[100],(128,128))
im1=Image.fromarray(np.uint8(img))
im1.show()



axis = W.argsort()[::-1]
print(axis)
V_img = V_img[:, axis]

number = 0
x = sum(W)
for i in range(len(axis)):
    number += W[axis[i]]
    if float(number) / x > 0.9:# 取累加有效值为0.9
        print('累加有效值是：', i) # 前18个特征值保存大部分特征信息
        break






import os
import urllib3
from PIL import Image
from io import BytesIO
import matplotlib.pyplot as plt
import numpy as np
import cv2
from skimage import io
import scipy.misc
from skimage.transform import resize
import imageio
from sklearn.decomposition import PCA
import shutil
from sklearn.model_selection import train_test_split



os.mkdir("npy\\")
os.mkdir("jpg\\")
for filename in  os.listdir(os.getcwd() + "\\" + "rawdata\\"):              #rawdata  的位置需要根据原始数据的路径改变
    file=open("rawdata\\"+filename,'rb')
    x=np.fromfile(file,dtype=np.ubyte)
    if x.size==128**2:
        x=x.reshape(128,-1)
    else:
        x=Image.fromarray(x)
        x=x.resize((128,128),Image.ANTIALIAS)
        x=np.array(x)
    np.save("npy\\"+filename,x)
    file.close()
    test=np.load("npy\\"+filename+".npy")
    imageio.imwrite("jpg\\"+filename+".jpg",test)




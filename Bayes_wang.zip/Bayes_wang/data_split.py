import os
import shutil
from random import randrange
import os.path as osp


def divide_img(images_path,scale):
    save_train_path = "img_face_split\\train"
    save_test_path="img_face_split\\test"
    modnum=randrange(scale)
    i = 0
    for file in os.listdir(images_path):
        src_image=images_path+file
        if i % scale == modnum:           #train set
            save_path=os.getcwd()+"\\"+save_test_path+"\\"
            if not os.path.exists(save_path):
                os.makedirs(save_path)
            shutil.copy(src=src_image,dst=save_path)
        else:                 #test set
            save_path=os.getcwd()+"\\"+save_train_path+"\\"
            if not os.path.exists(save_path):
                os.makedirs(save_path)
            shutil.copy(src=src_image,dst=save_path)
            #一轮结束
        if i % scale == 0 and i !=0:
            modnum=randrange(scale)

        i+=1

if __name__=='__main__':
    img_root=os.getcwd()+"\\"+"output_128"+"\\"
    divide_img(img_root,9)
    print("finish")

    f = open('faceDR','r')
    r1 = f.readlines()
    f.close()

    f = open('faceDS','r')
    r2 = f.readlines()
    f.close()
    for i in r2:
        r1.append(i)


    for i in range(0,2):
        if i ==0:
            file=open(os.getcwd()+"\\"+"img_face_split\\"+"train_label.txt",'w')
            for filename in os.listdir(os.getcwd()+"\\"+"img_face_split\\"+"train\\"):
                name,type=filename.split('.')
                for l in r1:
                    if name in l:
                        if 'female' in l:
                            file.write('0\n')         #female
                        else:
                            file.write('1\n')       #male
            file.close()
        else:
            file=open(os.getcwd()+"\\"+"img_face_split\\"+"test_label.txt",'w')
            for filename in os.listdir(os.getcwd()+"\\"+"img_face_split\\"+"test\\"):
                name, type = filename.split('.')
                for l in r1:
                    if name in l:
                        if 'female' in l:
                            file.write('0\n')
                        else:
                            file.write('1\n')
            file.close()
            print("finish")

import os
import urllib3
from PIL import Image
from io import BytesIO
import matplotlib.pyplot as plt
import numpy as np
import cv2
from skimage import io
import scipy.misc
from skimage.transform import resize
import imageio
from sklearn.decomposition import PCA
import shutil
from sklearn.model_selection import train_test_split
#










import cv2
import numpy as np
from matplotlib import pyplot as plt

#很多图片亮度较暗，采用直方图均衡化  存入jpg1_light

os.mkdir("jpg_Histogram\\")
for filename in os.listdir(os.getcwd() + "\\" + "jpg\\"):
    img=cv2.imread(os.getcwd() + "\\" + "jpg" + "\\" + filename,0)
    print(img)
    dst=cv2.equalizeHist(img)
    print(dst)
    cv2.imwrite("jpg_Histogram\\"+filename,dst)





# 获取灰度图像
# img = cv2.imread("jpg1_light\\4032.jpg", 0)
# # 灰度图像的直方图
# hist = cv2.calcHist([img],[0],None,[256],[0,256])
# plt.figure()
# plt.title("Grayscale Histogram")
# plt.xlabel("Bins")
# plt.ylabel("# of Pixels")
# plt.plot(hist)
# plt.xlim([-10,256])
# plt.show()

# 灰度图像直方图均衡化
#dst = cv2.equalizeHist(img)
# cv2.imwrite("3897.jpg",dst)
# hist = cv2.calcHist([dst],[0],None,[256],[0,256])
# plt.figure()
# plt.hist(dst.ravel(), 256)
# plt.show()
# cv2.imshow("Histogram Equalization",np.hstack([img, dst]))
# cv2.waitKey(0)

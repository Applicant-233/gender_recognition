import cv2
import os
from PIL import Image
import imutils
import face_utils
import math
import shutil
faceCascade=cv2.CascadeClassifier("D:\\Anaconda3\\Lib\\site-packages\\cv2\\data\\haarcascade_frontalface_default.xml")



#人脸检测，切割  256维
def preprocess(img, name):
    image = img
    image = imutils.resize(image, width=500)
    shape = face_utils.points_68(image, 0)
    # loop over the face detections
    cen_1 = ((shape[36][0] + shape[39][0]) / 2, (shape[36][1] + shape[39][1]) / 2)
    cen_2 = ((shape[42][0] + shape[45][0]) / 2, (shape[42][1] + shape[45][1]) / 2)

    # setting distance between center of eyes = 128 pixels
    distance = math.sqrt(pow(cen_1[0] - cen_2[0], 2) + pow(cen_1[1] - cen_2[1], 2))
    if distance == 0 or distance > 128 or shape[29][0] < 128 or shape[29][1] < 128:
        crop_top_left_x = 250 - 128
        crop_top_right_y = 250 - 128
        cropped = image[crop_top_right_y: crop_top_right_y + 256, crop_top_left_x: crop_top_left_x + 256]
        gray = cv2.cvtColor(cropped, cv2.COLOR_BGR2GRAY)
        cv2.imwrite(name + ".jpg", gray)
        return gray
    ratio = 128 / distance
    h1 = int(image.shape[0] * ratio)
    w1 = int(image.shape[1] * ratio)
    dim = (w1, h1)
    resized_img = cv2.resize(img, dim)
    nose_center = (int(shape[29][0] * ratio), int(shape[29][1] * ratio))

    crop_top_left_x = nose_center[0] - 128
    crop_top_right_y = nose_center[1] - 128
    print(crop_top_right_y, crop_top_left_x)
    cropped = resized_img[crop_top_right_y: crop_top_right_y + 256, crop_top_left_x: crop_top_left_x + 256]
    gray = cv2.cvtColor(cropped, cv2.COLOR_BGR2GRAY)
    cv2.imwrite(name + ".jpg", gray)
    return gray


def input(n):
    name = n
    images = []
    for filename in os.listdir(os.getcwd() + "\\" + name):       #os.getcwd\\rawdata
        image = cv2.imread(os.getcwd() + "\\" + name + "\\" + filename, 1)
        images.append(image)
    return images

directory = "jpg_Histogram\\"

raw="rawdata\\"
print(directory)
print(os.getcwd())
r = input(directory)              #
os.mkdir("output_256_Histogram\\")                    #output_256_Histogram  or  output_256
x=0
data=[]
for i in os.listdir(os.getcwd()+"\\"+raw):
    a=int(i)
    data.append(i)

for img in r:
    image = preprocess(img, "output_256_Histogram\\"+ str(data[x]))                #output_256_Histogram  or  output_256
    x+=1



#将256维图像转为128维
os.mkdir("output_128_Histogram\\")                          #output_128_Histogram  or  output_128
for filename in os.listdir(os.getcwd()+"\\"+"output_256_Histogram\\"):
    x=Image.open(os.getcwd()+"\\"+"output_256_Histogram\\"+filename)
    x=x.resize((128,128),Image.ANTIALIAS)
    x.save("output_128_Histogram\\"+filename)






#Haar-cascade  not used
# for filename in os.listdir(os.getcwd() + "\\" + "jpg1\\"):
#     img=cv2.imread(os.getcwd() + "\\" + "jpg1" + "\\" + filename)
#     # dst = cv2.equalizeHist(img)
#     #imgGray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
#     face=faceCascade.detectMultiScale(img,1.1,4)
#     if len(face)==0:                       #图像缺失的
#         print(filename)
#         nopicture.append(filename)
#         cv2.imwrite(os.getcwd()+"\\"+"jpg2\\"+filename,img)
#     else:
#         for (x, y, w, h) in face:
#             #cv2.rectangle(img, (x - 5, y - 20), (x + w, y + h + 8), (255, 0, 0), 2)
#             crop_img = img[y-20:y+h+8,x-5:x+w]
#             cv2.imwrite("jpg2\\"+filename,crop_img)
#             break


# img1=cv2.imread('jpg1_light\\1273.jpg')
# #dst = cv2.equalizeHist(img1)
# imgGray1=cv2.cvtColor(img1,cv2.COLOR_BGR2GRAY)
# face1=faceCascade.detectMultiScale(imgGray1,1.1,4)
# if len(face1)==0:
#     print("nnn")
# for (x,y,w,h) in face1:
#     cv2.rectangle(img1,(x,y),(x+w,y+h),(255,0,0),2)
#     # crop_img=imgGray1[y-20:y+h+8,x-5:x+w]
#     # #print(crop_img)
#     # cv2.imwrite('1251.jpg',crop_img)
#     break
# cv2.imshow("Result",img1)
# cv2.waitKey(0)
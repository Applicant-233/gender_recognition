import os,glob,PIL,sys,math
import numpy
from PIL import Image,ImageChops
from numpy import linalg as la
import numpy as np
import cv2
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt


im,img1,classes_train,test_img, im_t ,classes_test= [],[],[],[],[],[]

for filename in os.listdir(os.getcwd() + "\\" + "img_face_Histogram_split\\" + "train\\"):
    img1.append(filename)
with open(os.getcwd()+"\\"+"img_face_Histogram_split\\"+"train_label.txt",'rt') as f1:
    for i in f1:
        temp=i[:-1]
        classes_train.append(temp)

for filename in os.listdir(os.getcwd()+"\\"+"img_face_Histogram_split\\"+"test\\"):
    test_img.append(filename)
with open(os.getcwd()+"\\"+"img_face_Histogram_split\\"+"test_label.txt",'rt') as f1:
    for i in f1:
        temp=i[:-1]
        classes_test.append(temp)


#image object to mat
#64*64
imsiz = 64
l11=len(img1)
for i in range(l11):
    n=Image.open(os.getcwd()+"\\"+"img_face_Histogram_split\\"+"train\\"+img1[i])
    n = n.convert('L')
    sz = n.size  #size
    ratio = float(sz[1] / sz[0])
    new_ht = imsiz
    new_wdt = int(math.floor(new_ht * ratio))
    n = n.resize((new_ht, new_wdt), Image.ANTIALIAS)
    t = numpy.array(n)
    im.append(t)        #matrix

num=len(im)
# num = len(im)
siz = im[0].shape
n_dim = siz[0] * siz[1]
x_mat = numpy.zeros((num,n_dim))
for i in range(num):
    x_mat[i] = im[i].flatten()


imageMatrix=x_mat



# for filename in os.listdir(os.getcwd()+"\\"+"img2\\"+"train\\"):
#     img=cv2.imread(os.getcwd()+"\\"+"img2\\"+"train\\"+filename,cv2.IMREAD_GRAYSCALE)
#     #灰度图矩阵
#     mats=np.array(img)
#     imageMatrix.append(mats.ravel())
imageMatrix=np.array(imageMatrix)               #   raw: n  colum: 128*128
l=len(img1)


#LDA
# imageMatrix_T=imageMatrix.T
# female=0
# male=0
# print(classes_train)
# for i in range(l):
#     if int(classes_train[i])==0:
#         female+=1
#     else:
#         male+=1
# print(male,female)

# train_classes_mean=np.zeros((4096,2))
# for i in range(2):
#     temp=train_classes_mean[:,i]
#     for j in range(l):
#         if int(classes_train[j])==i:
#             temp+=imageMatrix_T[:,j]
#     if i==0:                 #属于女性
#         train_classes_mean[:,i]=temp/female
#     else:                   #属于男性
#         train_classes_mean[:,i]=temp/male

#SB
# SB=np.zeros((4096,4096))
# all_mean=np.mean(imageMatrix_T,axis=1)
# for i in range(2):
#     centered_data=train_classes_mean[:,i]-all_mean
#     if i==0:
#         SB+=female * np.dot(centered_data,centered_data.T)
#     else:
#         SB+=male * np.dot(centered_data,centered_data.T)

#SW
# SW=np.zeros((4096,4096))
# for i in range(2):
#     for j in range(l):
#         if int(classes_train[j])==i:
#             centered_data=imageMatrix_T[:,j]-train_classes_mean[:,i]
#             SW+=np.dot(centered_data,centered_data.T)
#
# target=np.dot(la.pinv(SW),SB)
# eig_val,eig_vec=la.eigh(target)



#PCA
mn=np.mean(imageMatrix,axis=0)                       #average
# mean_img1 = np.reshape(mn,(128,128))
# print(mean_img1)
# imss = Image.fromarray(np.uint8(mean_img1))
# imss.show()

imageMatrix=imageMatrix-mn                     #substract the average

scale=1
fig=plt.figure(figsize=(10*scale, 10*scale))
columns = 10
rows = 10
for i in range(1,101):
    image=np.reshape(imageMatrix[i,:],(64,64))
    image=Image.fromarray(image)
    fig.add_subplot(rows, columns, i)
    plt.xticks([])
    plt.yticks([])
    plt.imshow(image)
plt.show()

imageMatrix_T=imageMatrix.T
sigma=np.dot(imageMatrix,imageMatrix_T)
eig_val,eig_vec=la.eig(sigma)                #A*A转置的特征向量
eig_vec=np.dot(imageMatrix_T,eig_vec)             #协方差矩阵A转置* A的特征向量
index=eig_val.argsort()[::-1]
eig_val=eig_val[index]
eig_vec=eig_vec[:,index]                       #从大到小对应的特征向量

number = 0
x = sum(eig_val)
for i in range(len(index)):
    number += eig_val[i]
    if float(number) / x > 0.9:# 取累加有效值为0.9
        print('累加有效值是：', i)
        break


# scale=1                       #show the eigenface
# fig=plt.figure(figsize=(10*scale, 10*scale))
# columns = 10
# rows = 10
# for i in range(1, 101):
#     img_eig = np.reshape(eig_vec[:,i],(64,64))
#     img_eig=Image.fromarray(np.uint8(img_eig))
#     # img_eig=ImageChops.invert(img_eig)
#     fig.add_subplot(rows, columns, i)
#     plt.xticks([])
#     plt.yticks([])
#     plt.imshow(img_eig)
# fig.suptitle('Top 100 Eigenfaces (PCA)', fontsize=14)
# plt.show()




#LDA
#eig_vec=eig_vec[:,:46]
#PCA
eig_vec=eig_vec[:,:36]

train_vec=np.dot(imageMatrix,eig_vec)


class_dup=classes_train               #训练集每张图片的类
classes=[]
for i in class_dup:
    if i not in classes:
        classes.append(i)           #1,0

grp={}
mn_var={}
l1=len(class_dup)
l2=len(classes)                 #2个类:0，1

for i in classes:
    grp[i]=[]

for i in range(l1):
    grp[(class_dup[i])].append((train_vec[i,:]))

for i in range(l2):
    mn_var[i,0]=[]
    mn_var[i,1]=[]

for i in range(l2):
    mn_var[i,0]=np.mean(np.array(grp[classes[i]]),axis=0)
    mn_var[i,1]=np.var(np.array(grp[classes[i]]),axis=0)



#测试集
l1 = len(test_img)
for i in range(l1):
    n= Image.open(os.getcwd()+"\\"+"img_face_Histogram_split\\"+"test\\"+test_img[i])
    n = n.convert('L')
    sz = n.size
    ratio = float(sz[1] / sz[0])
    new_ht = imsiz
    new_wdt = int(math.floor(new_ht * ratio))
    n = n.resize((new_ht,new_wdt),Image.ANTIALIAS)
    t = numpy.array(n)
    im_t.append(t)
num = len(im_t)
siz = im_t[0].shape
n_dim = siz[0] * siz[1]
test_mat = numpy.zeros((num,n_dim))
for i in range(num):
    test_mat[i] = im_t[i].flatten()


imageMatrix_test=test_mat
# for filename in os.listdir(os.getcwd()+"\\"+"img2\\"+"test\\"):                     #几张图
#     img=cv2.imread(os.getcwd()+"\\"+"img2\\"+"test\\"+filename,cv2.IMREAD_GRAYSCALE)
#     #灰度图矩阵
#     mats=np.array(img)
#     imageMatrix_test.append(mats.ravel())
imageMatrix_test=np.array(imageMatrix_test)

imageMatrix_test=imageMatrix_test-mn

test_class=[]
test_ft=np.matmul(imageMatrix_test,eig_vec)                #测试集的特征空间
# print(test_ft)
l1=test_ft.shape[0]
l2=test_ft.shape[1]
l3=len(classes)

ind_prob=np.zeros((1,l2))
tot_prob=np.zeros((1,l3))


for i in range(l1):
    mx=-10**9
    for j in range(l3):
        tot_prob[0,j]=1
        for k in range(l2):
            ind_prob[0,k]=np.exp((-(test_ft[i][k] - mn_var[j, 0][k]) ** 2) / (2 * (mn_var[j, 1][k]))) / ((2 * 3.1415 * (mn_var[j, 1][k])) ** .5)
            tot_prob[0, j] = tot_prob[0, j] * ind_prob[0, k]
    for j in range(l3):
        if mx < tot_prob[0, j]:
            mx = numpy.max(tot_prob[0, j])
            cla = j
    test_class.append(classes[cla])

kk=0
for i in range(len(test_class)):
    print(test_class[i])
    if test_class[i]==classes_test[i]:
        kk+=1
print('accuracy:',kk/len(classes_test),"%")

import os
import numpy as np
from sklearn.decomposition import PCA
from sklearn import svm
from sklearn.metrics import classification_report
from sklearn import datasets,discriminant_analysis
from sklearn.model_selection import KFold

def cal_cov_and_avg(samples,fea):
    """
    给定一个类别的数据，计算协方差矩阵和平均向量
    :param samples:
    :return:
    """
    u1 = np.mean(samples, axis=0)
    cov_m = np.zeros((samples.shape[1], samples.shape[1]))
    for s in samples:
        t = s - u1
        cov_m += t*t.reshape(fea, 1)
    return cov_m, u1

def fisher(c_1, c_2,fea):
    """
    fisher算法实现(参考上面的推导公式进行理解)
    :param c_1:
    :param c_2:
    :return:
    """
    cov_1, u1 = cal_cov_and_avg(c_1,fea)
    cov_2, u2 = cal_cov_and_avg(c_2,fea)
    s_w = cov_1 + cov_2          # 总类内离散度矩阵。
    u, s, v = np.linalg.svd(s_w) # 下面的参考公式（4-10）
    s_w_inv = np.dot(np.dot(v.T, np.linalg.inv(np.diag(s))), u.T)
    return np.dot(s_w_inv, u1 - u2)




if __name__ == '__main__':
    target = 'female'
    train_label=[]#训练标签
    test_label=[]#测试标签
    f=open('1faceDR.txt', encoding='gbk')
    txt=[]
    for line in f:
       if line.count(target):  # 寻找是否出现目标字符 女人是0 男人是1
          train_label.append(0)
       else:
          train_label.append(1)
       # txt.append(line.strip())
    f.close()  # 关闭文件
    # print(txt)
    f=open('2faceDS.txt', encoding='gbk')
    txt=[]
    for line in f:
       if line.count(target):  # 寻找是否出现目标字符 女人是0 男人是1
          test_label.append(0)
       else:
          test_label.append(1)
       # txt.append(line.strip())
    f.close()  # 关闭文件


    imgDataAll=[]
    imgDataAll=np.array(imgDataAll)
    imgDataTrain=[]
    imgDataTrain=np.array(imgDataTrain)
    for root,dirs,files in os.walk(r"train_data"):
       for file in files:
          # #获取文件所属目录
          # print(root)
          #获取文件路径
          filepath=os.path.join(root,file)
          imgData = np.fromfile(filepath, dtype='uint8')
          imgDataAll=np.append(imgDataAll,imgData)
          # print(os.path.join(root,file))
    # 利用numpy中array的reshape函数将读取到的数据进行重新排列。
    imgDataTrain=imgDataAll.reshape(1995,16384)


    imgDataAll=[]
    imgDataAll=np.array(imgDataAll)
    imgDataTest=[]
    imgDataTest=np.array(imgDataTest)
    for root,dirs,files in os.walk(r"test_data"):
       for file in files:
          # #获取文件所属目录
          # print(root)
          #获取文件路径
          filepath=os.path.join(root,file)
          imgData = np.fromfile(filepath, dtype='uint8')
          imgDataAll=np.append(imgDataAll,imgData)
          # print(os.path.join(root,file))
    # 利用numpy中array的reshape函数将读取到的数据进行重新排列。
    imgDataTest=imgDataAll.reshape(1996,16384)
    #
    # np.save("test_label.npy", test_label)
    # np.save("train_label.npy", train_label)
    # np.save("imgDataTrain.npy", imgDataTrain)
    # np.save("imgDataTest.npy", imgDataTest)

    # test_label=np.load('test_label.npy')
    # train_label=np.load('train_label.npy')
    # imgDataTrain=np.load('imgDataTrain.npy')
    # imgDataTest=np.load('imgDataTest.npy')

    #pca
    #从16384维降到500维
    fea=500
    pca = PCA(n_components=fea)
    pca_train=pca.fit_transform(imgDataTrain)
    a=pca.explained_variance_ratio_.sum()
    #打印前500维的贡献率
    print('pca score:',a)
    pca_test = pca.transform(imgDataTest)
    #flda，按照性别分离数据
    train_f=[]
    train_m=[]
    test_f=[]
    test_m=[]
    train_f = np.array(train_f)
    train_m = np.array(train_m)
    test_f = np.array(test_f)
    test_m = np.array(test_m)
    ii=0
    for i in range(len(pca_train)):
        if train_label[i]:
            train_m=np.append(train_m,pca_train[i,:])
            ii+=1
        else:
            train_f = np.append(train_f,pca_train[i,:])
    train_m=train_m.reshape(ii,fea)
    train_f=train_f.reshape(len(pca_train)-ii,fea)
    ii=0
    for i in range(len(pca_test)):
        if test_label[i]:
            test_m=np.append(test_m,pca_test[i,:])
            ii += 1
        else:
            test_f = np.append(test_f,pca_test[i,:])
    test_m=test_m.reshape(ii,fea)
    test_f=test_f.reshape(len(pca_test)-ii,fea)

    # np.save("train_m.npy", train_m)
    # np.save("train_f.npy", train_f)
    # np.save("test_m.npy", test_m)
    # np.save("test_f.npy", test_f)
    new_train_label = []
    new_test_label = []
    for i in range(len(train_m)):
        new_train_label.append(1)
    for i in range(len(train_f)):
        new_train_label.append(0)
    for i in range(len(test_m)):
        new_test_label.append(1)
    for i in range(len(test_f)):
        new_test_label.append(0)

    # from sklearn.datasets import make_multilabel_classification
    # x, y = make_multilabel_classification(n_samples=20, n_features=2,
    #                                       n_labels=1, n_classes=1,
    #                                       random_state=2)  # 设置随机数种子，保证每次产生相同的数据。
    #
    # # 根据类别分个类
    # index1 = np.array([index for (index, value) in enumerate(y) if value == 0])  # 获取类别1的indexs
    # index2 = np.array([index for (index, value) in enumerate(y) if value == 1])  # 获取类别2的indexs
    #
    # c_1 = x[index1]  # 类别1的所有数据(x1, x2) in X_1
    # c_2 = x[index2]  # 类别2的所有数据(x1, x2) in X_2

    # w = fisher(c_1, c_2)

    w=fisher(train_m,train_f,fea)
    trainM = np.dot(train_m,w)
    trainF = np.dot(train_f,w)
    testM = np.dot(test_m,w)
    testF = np.dot(test_f,w)
    new_train = np.append(trainM,trainF)
    new_test = np.append(testM, testF)

    #svm
    from sklearn.svm import LinearSVC
    pca_svc = svm.SVC(C=1.0,kernel='rbf')

    #只用svm
    # pca_svc.fit(imgDataTrain, train_label)  # 训练模型
    # y_predict = pca_svc.predict(imgDataTest) # 进行预测
    #
    # print('The Accuracy of Linear SVC is', pca_svc.score(imgDataTest,test_label))
    # print(classification_report(test_label, y_predict, target_names=['女','男']))

    #svm+pca
    # pca_svc.fit(pca_train, train_label)  # 训练模型
    # y_predict = pca_svc.predict(pca_test) # 进行预测
    #
    # print('The Accuracy of Linear SVC after PCA is', pca_svc.score(pca_test,test_label))
    # print(classification_report(test_label, y_predict, target_names=['女','男']))

    #svm+pca+flda
    new_train = new_train.reshape(-1,1)
    new_test = new_test.reshape(-1,1)
    pca_svc.fit(new_train, new_train_label)  # 训练模型
    y_predict = pca_svc.predict(new_test) # 进行预测

    print('The Accuracy of Linear SVC after PCA and FLDA is', pca_svc.score(new_test,new_test_label))
    print(classification_report(new_test_label, y_predict, target_names=['女','男']))

    # kf = KFold(1995, n_folds=10, shuffle=False)
    # for i, (train_index, test_index) in enumerate(kf):
    #     print(i, train_index, test_index)
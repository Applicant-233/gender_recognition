% DS_1223-3222
% DR_3223-5222

num = 2090;
img_name = 'rawdata/1223';
fid1 = fopen( 'faceDR','r');
while(1)
    if(num<3223)
        fid1 = fopen( 'faceDR','r');
        label_detail = fgetl(fid1);
        current_num = str2double(label_detail(2:5));
        while(current_num < num)
            label_detail = fgetl(fid1);
            current_num = str2double(label_detail(2:5));
        end
        fprintf('%s\n',label_detail);
        fclose(fid1);
    else
        fid1 = fopen( 'faceDS','r');
        label_detail = fgetl(fid1);
        current_num = str2double(label_detail(2:5));
        while(current_num < num)
            label_detail = fgetl(fid1);
            current_num = str2double(label_detail(2:5));
        end
        fprintf('%s\n',label_detail);
        fclose(fid1);
    end
    
    fig1 = figure(1);
    img_name(9:12) = num2str(num);
    if(exist(img_name,'file'))
        fig1.Name = img_name;
        fid2=fopen(img_name,'r'); 
        I = fread(fid2);
        fclose(fid2);
        side_l = sqrt(length(I));
        imagesc(reshape(I, side_l, side_l)');
        if(side_l ~= 128)
            fprintf('>>>>>>>>>>>>>��ͼƬ���ش���128*128��<<<<<<<<<<<<<<\n');
        end
        colormap(gray(256));
        if(label_detail(14) == 'm')
            gender = '��';
        else
            gender = 'Ů';
        end
        text(10,10,gender,'color','g','fontsize',20);
    else
        fig1.Name = img_name;
        image(zeros(128,128));
        colormap(gray(256));
        text(10,10,'ͼ��ȱʧ','color','r','fontsize',15);
    end
    
    pause;
    num = num+1;
end


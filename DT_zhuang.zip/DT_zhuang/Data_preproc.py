"""Data Preprocessing 数据预处理"""
import numpy
import os
from PIL import Image

class FACE():
    """
    【人脸数据处理成类】
    输入：
    raw_dir-原始数据所在目录（包含rawdata文件夹和faceDR、faceDS文件）
    变量：
    data-图像数据扁平矩阵(n,d^2)
    image-图像数据矩阵(n,d,d)
    target-性别卷标矩阵（0女，1男）
    label-详细卷标列表
    number-图片号列表
    size-图片数量
    方法：
    find_lb(lable)
    delete(nums)
    index(number)
    """ 
    def __init__(self,raw_dir):
        print('导入数据...')
        with open(raw_dir + '/faceDR','r') as f:
            labels = f.readlines()  # 完整详细卷标
        with open(raw_dir + '/faceDS','r') as f:
            for i in f.readlines():
                labels.append(i)    
        self.number = os.listdir(raw_dir + '/rawdata')  # 存在图片的号码(str)  
        self.label = []  # 整理后的详细卷标
        for i in self.number:  # 删除缺失图像的卷标
            for j in labels:
                if i in j:
                    self.label.append(j)
                    tag0 = 1
                    break
        for i in labels:  
            if 'missing' in i:
                print(i[1:5], '缺失')
        length = len(self.number)
        self.size = length
        self.data = numpy.zeros((length,128**2))
        self.image = numpy.zeros((length,128,128))  # 图像数据矩阵（n*128*128）
        self.target = numpy.zeros(length, dtype='int64')  # 性别卷标矩阵（0女，1男）
        for i in range(length):
            with open(raw_dir + '/rawdata/' + self.number[i],'rb') as f:
                temp = numpy.fromfile(f, dtype=numpy.ubyte)
                if temp.size==128**2:  # 正常大小
                    self.data[i] = temp
                    temp = temp.reshape(128,-1)
                    self.image[i] = temp
                else:  # 需压缩图片
                    im = Image.fromarray(temp.reshape(512,512))
                    temp = im.resize((128, 128), Image.ANTIALIAS)  # 改变尺寸，保持图片高品质
                    print(self.number[i], '已压缩为128*128')        
                    self.image[i] = temp
                if 'female' in self.label[i]:
                    self.target[i] = 0
                elif 'male' in self.label[i]:
                    self.target[i] = 1
                else:
                    self.target[i] = None
        for i in range(len(self.number)):  # 图片号转为int型
            self.number[i] = int(self.number[i])
        print('导入完成！')
                    
                    
    def find_lb(self,label):
        '''find label 返回含有输入卷标的图片号码表'''
        temp = []
        for i in range(self.size):
            if label in self.label[i]:
                temp.append(self.number[i])
        return temp
                       
                       
    def delete(self,nums):
        '''关联性删除输入号码列表对应的数据'''
        if isinstance(nums,list) or isinstance(nums,tuple):
            sum = 0
            not_exist = []
            print('deleting:  ', end='')
            for i in nums:
                if int(i) in self.number:
                    idx = self.number.index(int(i))
                    self.number.pop(idx)
                    self.label.pop(idx)
                    self.data = numpy.delete(self.data,idx,0)
                    self.image = numpy.delete(self.image,idx,0)
                    self.target = numpy.delete(self.target,idx,0)
                    self.size -= 1
                    sum += 1
                    print('%d ' % int(i), end=' ')
                else:
                    not_exist.append(i)
            print('\ndeleted %d/%d images!' % (sum, len(nums)))
            if not_exist:
                print('No.', not_exist, 'don\'t seem to exist')
        else:
            if int(nums) in self.number:
                idx = self.number.index(int(nums))
                self.number.pop(idx)
                self.label.pop(idx)
                self.data = numpy.delete(self.data,idx,0)
                self.image = numpy.delete(self.image,idx,0)
                self.target = numpy.delete(self.target,idx,0)
                self.size -= 1
                print('deleted %d!' % int(nums))
            else:
                print('No.', nums, 'doesn\'t seem to exist')
            
    def index(self,nums):
        '''返回输入图片号在数据中的索引（全部匹配才能正常返回）'''
        if isinstance(nums,list) or isinstance(nums,tuple):
            idx = []
            tag = False
            nums = list(nums)
            for j in nums:
                for i in range(self.size):
                    if int(j)==self.number[i]:
                        idx.append(i)
                        tag = True
                    if i >= self.size-1:
                        if not tag:
                            print('No.', j, 'doesn\'t seem to exist')
                            return
                        tag = False
            return idx
        else:
            for i in range(self.size):
                if int(nums)==self.number[i]:
                    return i
            print('No.', nums, 'doesn\'t seem to exist')
        
            